# Car Ownership — production kit

- `car-ownership-1080p.mp4`: final 1080p video, Michael narration, original score/Foley, selectable English captions and chapters.
- `deliverables/`: thumbnail, English SRT, clean Michael narration, scene timing, financial model, sources and verification.
- `source/`: editable Motion Canvas project. Run `npm ci` and `npm start` inside this folder. The complete soundtrack is included. See its README for voice regeneration.

Duration: approximately 8 minutes 31 seconds. This is an illustrative five-year scenario, not a national average.
